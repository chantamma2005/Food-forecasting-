create a preprocessing file to process all the features scale and normalize them and later do PCA on it,
then input those 2 features into the model. (either it could be single row values or excel file.)

make the code accept both the types.
later :

"if necessaryadd some plottingand analysis of data and predict the cluster belong to and classify it acc to the data"

add a proper template and do refer to the previously built flask app for better understanding.